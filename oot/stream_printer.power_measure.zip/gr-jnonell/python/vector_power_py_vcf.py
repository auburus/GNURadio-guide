#!/usr/bin/env python
# -*- coding: utf-8 -*-
# 
# Copyright 2016 <+YOU OR YOUR COMPANY+>.
# 
# This is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3, or (at your option)
# any later version.
# 
# This software is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this software; see the file COPYING.  If not, write to
# the Free Software Foundation, Inc., 51 Franklin Street,
# Boston, MA 02110-1301, USA.
# 

import numpy
from gnuradio import gr

class vector_power_py_vcf(gr.sync_block):
    """
    docstring for block vector_power_py_vcf
    """
    def __init__(self, samples):
        self.samples = samples

        gr.sync_block.__init__(self,
            name="vector_power_py_vcf",
            in_sig=[(numpy.complex64, self.samples)],
            out_sig=[numpy.float32])


    def work(self, input_items, output_items):
        in0 = input_items[0]
        out = output_items[0]

        powers = []
        for vector in in0:
            power = 0
            for value in vector:
                power += abs(value)**2
            powers.append(float(power)/self.samples)

        out[:] = powers
        return len(output_items[0])

